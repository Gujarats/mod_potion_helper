::PotionHelper.getPrice <- function( _key )
{
    local price = ::PotionHelper.conf(_key);
    if (!::PotionHelper.conf("EnablePriceScaling") || !("World" in getroottable()) || ::World.getPlayerRoster() == null)
    {
        return price;
    }

    local highest = 1;
    local count = 0;
    foreach (bro in ::World.getPlayerRoster().getAll())
    {
        if (!bro.isGuest())
        {
            highest = ::Math.max(highest, bro.getLevel());
            ++count;
        }
    }

    return ::Math.round(price * (1.0 + (highest - 1) * 0.02 + count * 0.01));
};

::PotionHelper.restoreHealth <- function( _actor, _tier )
{
    local amount = ::Math.ceil(_actor.getHitpointsMax() * ::PotionHelper.conf(::PotionHelper.Tiers[_tier].Pct) / 100.0);
    _actor.setHitpoints(::Math.min(_actor.getHitpointsMax(), _actor.getHitpoints() + amount));
};
